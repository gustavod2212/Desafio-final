// main.js — pequeno arquivo global (atualmente só placeholder)
console.log("Loja Multivariada — carregado main.js");
