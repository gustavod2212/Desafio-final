/* products.js
 - Carrega de https://dummyjson.com/products
 - Permite adicionar/remover localmente
 - Valida: título, descrição, marca e categoria (3–50 chars)
 - preço: número >0 e <120
 - thumbnail: URL opcional válida
*/

// elementos
const productForm = document.getElementById('productForm');
const productsList = document.getElementById('productsList');
const productError = document.getElementById('productFormError');

const titleInput = document.getElementById('title');
const brandInput = document.getElementById('brand');
const categoryInput = document.getElementById('category');
const priceInput = document.getElementById('price');
const thumbnailInput = document.getElementById('thumbnail');
const descriptionInput = document.getElementById('description');

let products = [];

function isValidURL(str){
  if(!str) return true;
  try { new URL(str); return true; } catch { return false; }
}

function escapeHtml(s){
  return (s+'').replace(/[&<>\"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}

function renderProductCard(product, idx){
  const wrap = document.createElement('div');
  wrap.className = 'card card-item';

  const imgUrl = product.thumbnail || 'https://via.placeholder.com/160x120.png?text=Produto';

  wrap.innerHTML = `
    <img src="${imgUrl}" alt="${escapeHtml(product.title)}">
    <div class="meta">
      <strong>${escapeHtml(product.title)}</strong>
      <div class="small-muted">${escapeHtml(product.brand)} • ${escapeHtml(product.category)}</div>
      <div>${escapeHtml(product.description || '')}</div>
      <div style="margin-top:6px"><strong>R$ ${Number(product.price).toFixed(2)}</strong></div>
    </div>
    <div class="actions">
      <button class="btn-link remove" data-idx="${idx}">Remover</button>
    </div>
  `;

  wrap.querySelector('.remove').addEventListener('click', () => {
    products.splice(idx, 1);
    rerenderProducts();
  });

  return wrap;
}

function rerenderProducts(){
  productsList.innerHTML = '';
  products.forEach((p,i) => productsList.appendChild(renderProductCard(p,i)));
}

function validateProductInput(title, description, brand, category, price, thumbnail){
  if (!title || title.length < 3 || title.length > 50) return 'Título deve ter 3–50 caracteres.';
  if (!description || description.length < 3 || description.length > 50) return 'Descrição deve ter 3–50 caracteres.';
  if (!brand || brand.length < 3 || brand.length > 50) return 'Marca deve ter 3–50 caracteres.';
  if (!category || category.length < 3 || category.length > 50) return 'Categoria deve ter 3–50 caracteres.';
  const p = Number(price);
  if (Number.isNaN(p) || p <= 0 || p >= 120) return 'Preço deve ser número >0 e <120.';
  if (thumbnail && !isValidURL(thumbnail)) return 'URL da foto inválida.';
  return '';
}

// carregar da API
async function loadProductsFromApi(){
  try {
    const res = await fetch('https://dummyjson.com/products');
    if(!res.ok) throw new Error('Falha ao buscar produtos');
    const data = await res.json();
    products = data.products.map(p => ({
      title: p.title || '',
      description: p.description || '',
      price: p.price || 0,
      brand: p.brand || '',
      category: p.category || '',
      thumbnail: p.thumbnail || ''
    }));
    rerenderProducts();
  } catch(err){
    console.error('Erro ao carregar produtos:', err);
  }
}

// submit
productForm.addEventListener('submit', (e) => {
  e.preventDefault();
  productError.textContent = '';

  const title = titleInput.value.trim();
  const description = descriptionInput.value.trim();
  const brand = brandInput.value.trim();
  const category = categoryInput.value.trim();
  const price = priceInput.value.trim();
  const thumbnail = thumbnailInput.value.trim();

  const err = validateProductInput(title, description, brand, category, price, thumbnail);
  if (err){
    productError.textContent = err;
    return;
  }

  products.unshift({
    title, description, brand, category, price: Number(price), thumbnail
  });
  rerenderProducts();
  productForm.reset();
});

loadProductsFromApi();
