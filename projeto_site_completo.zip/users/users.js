/* users.js
 - Carrega lista inicial de https://dummyjson.com/users
 - Permite adicionar e remover localmente (DOM). Não fazemos POST real.
 - Valida conforme requisitos:
   - nomes/títulos: 3–50 chars obrigatórios
   - email: regex fornecido
   - idade: >0 e <120
   - foto: URL válida (opcional)
*/

// seleção de elementos
const form = document.getElementById('userForm');
const usersList = document.getElementById('usersList');
const errorEl = document.getElementById('userFormError');

const firstNameInput = document.getElementById('firstName');
const lastNameInput = document.getElementById('lastName');
const emailInput = document.getElementById('email');
const ageInput = document.getElementById('age');
const imageInput = document.getElementById('image');

// regex de email (compactada em uma linha)
const emailRegex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

let users = []; // manterá lista local (carregada da API + adicionados)

// util: valida URL
function isValidURL(str) {
  if (!str) return true; // campo opcional
  try {
    new URL(str);
    return true;
  } catch { return false; }
}

// util: cria elemento do usuário
function renderUserCard(user, idx) {
  const wrap = document.createElement('div');
  wrap.className = 'card card-item';

  const imgUrl = user.image || 'https://via.placeholder.com/120x120.png?text=User';

  wrap.innerHTML = `
    <img src="${imgUrl}" alt="Foto de ${escapeHtml(user.firstName)}">
    <div class="meta">
      <strong>${escapeHtml(user.firstName)} ${escapeHtml(user.lastName)}</strong>
      <div class="small-muted">${escapeHtml(user.email)} • ${escapeHtml(String(user.age))} anos</div>
    </div>
    <div class="actions">
      <button class="btn-link remove" data-idx="${idx}">Remover</button>
    </div>
  `;

  wrap.querySelector('.remove').addEventListener('click', () => {
    users.splice(idx, 1);
    rerenderUsers();
  });

  return wrap;
}

// evitar XSS simples ao injetar texto
function escapeHtml(s){
  return (s+'').replace(/[&<>\"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}

function rerenderUsers(){
  usersList.innerHTML = '';
  users.forEach((u,i) => usersList.appendChild(renderUserCard(u,i)));
}

// carregar da API
async function loadUsersFromApi(){
  try {
    const res = await fetch('https://dummyjson.com/users');
    if(!res.ok) throw new Error('Falha ao buscar usuários');
    const data = await res.json();
    // mapeia campos conforme instrução
    users = data.users.map(u => ({
      firstName: u.firstName || '',
      lastName: u.lastName || '',
      email: u.email || '',
      age: u.age || 0,
      image: u.image || u.avatar || ''
    }));
    rerenderUsers();
  } catch(err){
    console.error('Erro ao carregar usuários:', err);
    // deixar a lista vazia — usuário pode adicionar localmente
  }
}

// valida form
function validateUserInput(firstName, lastName, email, age, image){
  if (!firstName || firstName.length < 3 || firstName.length > 50) return 'Nome deve ter 3–50 caracteres.';
  if (!lastName || lastName.length < 3 || lastName.length > 50) return 'Sobrenome deve ter 3–50 caracteres.';
  if (!email || !emailRegex.test(email)) return 'Email inválido.';
  if (!age || Number.isNaN(Number(age)) || Number(age) <= 0 || Number(age) >= 120) return 'Idade deve ser número entre 1 e 119.';
  if (image && !isValidURL(image)) return 'URL da foto inválida.';
  return '';
}

// submit handler
form.addEventListener('submit', (e) => {
  e.preventDefault();
  errorEl.textContent = '';

  const firstName = firstNameInput.value.trim();
  const lastName = lastNameInput.value.trim();
  const email = emailInput.value.trim();
  const age = ageInput.value.trim();
  const image = imageInput.value.trim();

  const err = validateUserInput(firstName, lastName, email, age, image);
  if (err){
    errorEl.textContent = err;
    return;
  }

  // adiciona localmente
  users.unshift({ firstName, lastName, email, age: Number(age), image });
  rerenderUsers();
  form.reset();
});

// inicialização
loadUsersFromApi();
